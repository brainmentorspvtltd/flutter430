import '../../../shared/services/dio_client.dart';
import '../models/Post.dart';

class PostRepo {
  final DioClient dioClient;
  PostRepo({required this.dioClient});

  Future<List<Post>> getAllPosts() async {
    try {
      final response = await dioClient.get('/posts');
      final data = response as List;
      final List<Post> postList =
          data.map((item) => Post.fromJson(item)).toList();
      return postList;
    } catch (err) {
      return [];
    }
  }

  Future<void> deletePost(int postId) async {
    try {
      await dioClient.delete("/posts/$postId");
    } catch (err) {
      print(err);
    }
  }

  Future<void> addPost(int userId, String title, String body) async {
    final Map<String, dynamic> data = {
      "userId": userId,
      "title": title,
      "body": body,
    };
    try {
      await dioClient.post("/posts", data);
    } catch (err) {
      print(err);
    }
  }
}
