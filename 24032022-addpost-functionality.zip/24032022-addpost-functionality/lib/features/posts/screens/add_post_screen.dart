import 'package:flutter/material.dart';

import '../../../shared/widgets/custom_text_field.dart';
import '../blocs/post_bloc.dart';

class AddPostScreen extends StatefulWidget {
  const AddPostScreen({Key? key}) : super(key: key);

  @override
  _AddPostScreenState createState() => _AddPostScreenState();
}

class _AddPostScreenState extends State<AddPostScreen> {
  late final PostBloc _postBloc;

  final _formKey = GlobalKey<FormState>();
  String title = "";
  String body = "";
  int userId = 1;

  void onTitleChanged(String? value) {
    setState(() {
      title = value!;
    });
  }

  void onBodyChanged(String? value) {
    setState(() {
      body = value!;
    });
  }

  @override
  void initState() {
    _postBloc = PostBloc();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Add a new post"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Form(
          key: _formKey,
          autovalidateMode: AutovalidateMode.onUserInteraction,
          child: Column(
            children: [
              TitleField(
                onChanged: onTitleChanged,
              ),
              const SizedBox(height: 20),
              BodyField(onChanged: onBodyChanged),
              const SizedBox(height: 40),
              ElevatedButton(onPressed: onSubmit, child: const Text("Submit"))
            ],
          ),
        ),
      ),
    );
  }

  void onSubmit() {
    if (_formKey.currentState!.validate()) {
      _formKey.currentState!.save();
      _postBloc.addPost(userId, title, body);
    }
  }
}

class TitleField extends StatelessWidget {
  const TitleField({Key? key, required this.onChanged}) : super(key: key);
  final Function(String? value) onChanged;
  @override
  Widget build(BuildContext context) {
    return CustomTextField(
      validator: (String? value) {
        if (value == null || value.isEmpty) {
          return "Please add title";
        }
      },
      onChanged: onChanged,
      labelText: "Title",
      hintText: "Add title",
    );
    ;
  }
}

class BodyField extends StatelessWidget {
  const BodyField({Key? key, required this.onChanged}) : super(key: key);
  final Function(String? value) onChanged;

  @override
  Widget build(BuildContext context) {
    return CustomTextField(
      validator: (String? value) {
        if (value == null || value.isEmpty) {
          return "Please add body";
        }
      },
      onChanged: onChanged,
      labelText: "Body",
      hintText: "Add body",
    );
    ;
  }
}
