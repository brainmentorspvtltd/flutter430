import 'package:dio/dio.dart';

class DioClient {
  static const baseUrl = "https://jsonplaceholder.typicode.com";
  final Dio dio = Dio();
  DioClient() {
    dio.options.baseUrl = baseUrl;
  }

  Future<dynamic> get(String uri) async {
    try {
      final response = await dio.get(uri);
      return response.data;
    } catch (err) {
      rethrow;
    }
  }

  Future<void> post(String uri, Map<String, dynamic> dataMap) async {
    try {
      final response = await dio.post(uri, data: dataMap);
      print('From Post');
      print(response);
      return response.data;
    } catch (err) {
      rethrow;
    }
  }

  Future<void> delete(String uri) async {
    try {
      final response = await dio.delete(uri);
      print(response);
      //return response.data;
    } catch (err) {
      rethrow;
    }
  }
}
