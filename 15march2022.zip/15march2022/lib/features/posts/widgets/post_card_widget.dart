import 'package:flutter/material.dart';

import '../models/Post.dart';

class PostCardWidget extends StatelessWidget {
  const PostCardWidget({Key? key, required this.post}) : super(key: key);
  final Post post;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListTile(
          title: Text(post.title),
          subtitle: Text(post.body),
        ),
      ),
    );
  }
}
