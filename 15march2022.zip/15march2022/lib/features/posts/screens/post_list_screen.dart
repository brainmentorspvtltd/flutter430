import 'package:curdzerotohero/features/posts/models/Post.dart';
import 'package:flutter/material.dart';

import '../blocs/post_bloc.dart';
import '../widgets/post_card_widget.dart';

class PostListScreen extends StatefulWidget {
  const PostListScreen({Key? key}) : super(key: key);

  @override
  _PostListScreenState createState() => _PostListScreenState();
}

class _PostListScreenState extends State<PostListScreen> {
  late final PostBloc _postBloc;

  @override
  void initState() {
    _postBloc = PostBloc();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Post List"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FutureBuilder<List<Post>>(
          future: _postBloc.getAllPosts(),
          builder: (BuildContext context, snapshot) {
            if (snapshot.hasData) {
              final List<Post> posts = snapshot.data!;
              return ListView.builder(
                  itemCount: posts.length,
                  itemBuilder: (BuildContext context, index) {
                    final post = posts[index];
                    return PostCardWidget(post: post);
                  });
            }
            return const Center(child: CircularProgressIndicator());
          },
        ),
      ),
    );
  }
}
