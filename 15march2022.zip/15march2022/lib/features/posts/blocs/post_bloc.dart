import 'package:curdzerotohero/features/posts/repositories/post_repo.dart';

import '../../../shared/services/dio_client.dart';
import '../models/Post.dart';

class PostBloc {
  final PostRepo _postRepo = PostRepo(dioClient: DioClient());

  Future<List<Post>> getAllPosts() async {
    final posts = await _postRepo.getAllPosts();
    return posts;
  }
}
