import '../../../shared/services/dio_client.dart';
import '../models/Post.dart';

class PostRepo {
  final DioClient dioClient;
  PostRepo({required this.dioClient});

  Future<List<Post>> getAllPosts() async {
    try {
      final response = await dioClient.get('/posts');
      final data = response as List;
      final List<Post> postList =
          data.map((item) => Post.fromJson(item)).toList();
      return postList;
    } catch (err) {
      return [];
    }
  }
}
