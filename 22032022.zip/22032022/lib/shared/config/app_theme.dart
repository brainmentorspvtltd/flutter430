import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  static ThemeData lightThemeData = themeData(_lightColorScheme);
  static ThemeData darkThemeData = themeData(_darkColorScheme);

  static ThemeData themeData(ColorScheme colorScheme) {
    return ThemeData(
      primaryColor: colorScheme.primary,
      textTheme: _textTheme,
      // scaffoldBackgroundColor: colorScheme.secondary,
      colorScheme: colorScheme,
    );
  }

  static const _lightColorScheme = ColorScheme(
    brightness: Brightness.light,
    primary: Color(0xffc5e1a5),
    secondary: Color(0xff80cbc4),
    background: Colors.white,
    error: Colors.red,
    surface: Colors.pink,
    onPrimary: Colors.black,
    onError: Colors.white,
    onBackground: Colors.black45,
    onSecondary: Colors.black,
    onSurface: Colors.black,
  );
  static const _darkColorScheme = ColorScheme(
    brightness: Brightness.light,
    primary: Color(0xffaed581),
    secondary: Color(0xff80cbc4),
    background: Colors.white,
    error: Colors.red,
    surface: Colors.grey,
    onPrimary: Colors.white,
    onError: Colors.white,
    onBackground: Colors.black45,
    onSecondary: Colors.black,
    onSurface: Colors.black,
  );

  static final _textTheme = TextTheme(
    headline1: GoogleFonts.rubik(
        fontSize: 98, fontWeight: FontWeight.w300, letterSpacing: -1.5),
    headline2: GoogleFonts.rubik(
        fontSize: 61, fontWeight: FontWeight.w300, letterSpacing: -0.5),
    headline3: GoogleFonts.rubik(fontSize: 49, fontWeight: FontWeight.w400),
    headline4: GoogleFonts.rubik(
        fontSize: 35, fontWeight: FontWeight.w400, letterSpacing: 0.25),
    headline5: GoogleFonts.rubik(fontSize: 24, fontWeight: FontWeight.w400),
    headline6: GoogleFonts.rubik(
        fontSize: 20, fontWeight: FontWeight.w500, letterSpacing: 0.15),
    subtitle1: GoogleFonts.rubik(
        fontSize: 16, fontWeight: FontWeight.w400, letterSpacing: 0.15),
    subtitle2: GoogleFonts.rubik(
        fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 0.1),
    bodyText1: GoogleFonts.rubik(
        fontSize: 16, fontWeight: FontWeight.w400, letterSpacing: 0.5),
    bodyText2: GoogleFonts.rubik(
        fontSize: 14, fontWeight: FontWeight.w400, letterSpacing: 0.25),
    button: GoogleFonts.rubik(
        fontSize: 14, fontWeight: FontWeight.w500, letterSpacing: 1.25),
    caption: GoogleFonts.rubik(
        fontSize: 12, fontWeight: FontWeight.w400, letterSpacing: 0.4),
    overline: GoogleFonts.rubik(
        fontSize: 10, fontWeight: FontWeight.w400, letterSpacing: 1.5),
    // titleLarge: GoogleFonts.roboto(
    //     fontWeight: FontWeight.bold, fontSize: 20, color: Colors.red),
  );
}

//complete dart theme use dark shades
//try to change other font type
//add appbarTHeme and elevatedButton theme
