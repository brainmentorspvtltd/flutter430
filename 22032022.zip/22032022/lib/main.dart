import 'package:curdzerotohero/features/posts/screens/post_list_screen.dart';
import 'package:curdzerotohero/shared/config/app_theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'features/posts/screens/post_detail_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitDown,
    DeviceOrientation.portraitUp,
  ]);

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter',
      theme: AppTheme.lightThemeData,
      darkTheme: AppTheme.darkThemeData,
      themeMode: ThemeMode.light,
      routes: {
        "/": (context) => const PostListScreen(),
        "/post-details": (context) => const PostDetailScreen(),
      },
    );
  }
}
