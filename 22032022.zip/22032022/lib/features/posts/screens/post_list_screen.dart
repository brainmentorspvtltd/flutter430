import 'package:auto_size_text/auto_size_text.dart';
import 'package:curdzerotohero/features/posts/models/Post.dart';
import 'package:flutter/material.dart';

import '../blocs/post_bloc.dart';
import '../widgets/post_card_widget.dart';

class PostListScreen extends StatefulWidget {
  const PostListScreen({Key? key}) : super(key: key);

  @override
  _PostListScreenState createState() => _PostListScreenState();
}

class _PostListScreenState extends State<PostListScreen> {
  late final PostBloc _postBloc;

  @override
  void initState() {
    _postBloc = PostBloc();
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // elevation: 0,
        //  backgroundColor: Colors.transparent,
        title: AutoSizeText(
          "Post List",
          style: Theme.of(context)
              .textTheme
              .headline4
              ?.copyWith(fontWeight: FontWeight.bold),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FutureBuilder<List<Post>>(
          future: _postBloc.getAllPosts(),
          builder: (BuildContext context, AsyncSnapshot<List<Post>> snapshot) {
            if (snapshot.hasData) {
              final List<Post> posts = snapshot.data!;
              return ListView.builder(
                  itemCount: posts.length,
                  itemBuilder: (BuildContext context, index) {
                    final post = posts[index];
                    return Dismissible(
                        direction: DismissDirection.startToEnd,
                        background: Container(color: Colors.red),
                        secondaryBackground: Container(color: Colors.green),
                        confirmDismiss: (DismissDirection direction) async {
                          if (direction == DismissDirection.startToEnd) {
                            return showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                      // title: Text("Are You Sure?"),
                                      content: const Text(
                                          "Are You Sure to Delete This Row?"),
                                      actions: [
                                        TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop(false);
                                            },
                                            child: const Text("Cancel")),
                                        TextButton(
                                            onPressed: () async {
                                              await _postBloc
                                                  .deleteSinglePost(post.id);
                                              setState(() {
                                                posts.removeAt(index);
                                              });
                                              Navigator.of(context).pop(true);
                                            },
                                            child: const Text("OK"))
                                      ],
                                    ));
                          }
                        },
                        onDismissed: (DismissDirection direction) async {},
                        key: Key(
                          "${post.id}",
                        ),
                        child: PostCardWidget(post: post));
                    //return PostCardWidget(post: post);
                  });
            }
            return const Center(child: CircularProgressIndicator());
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
      ),
    );
  }
}
