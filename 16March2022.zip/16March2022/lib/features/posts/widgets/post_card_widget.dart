import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';

import '../models/Post.dart';

class PostCardWidget extends StatelessWidget {
  const PostCardWidget({Key? key, required this.post}) : super(key: key);
  final Post post;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListTile(
          leading: const FlutterLogo(
            size: 40,
          ),
          title: Text(
            post.title,
            maxLines: 1,
            style: const TextStyle(
              fontSize: 25,
            ),
          ),
          subtitle: Text(post.body, maxLines: 2),
        ),
      ),
    );
  }
}

class VerticalPostCard extends StatelessWidget {
  const VerticalPostCard({Key? key, required this.post}) : super(key: key);
  final Post post;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigator.of(context).push(
        //   MaterialPageRoute(builder: (context) => PostDetailScreen()),
        // );
        Navigator.of(context).pushNamed("/post-details", arguments: post);
      },
      child: Padding(
        padding: const EdgeInsets.only(bottom: 18.0),
        child: Card(
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.arrow_drop_down_circle),
                title: Text(
                  post.title,
                  style: const TextStyle(fontSize: 20),
                ),
                subtitle: AutoSizeText(
                  post.body,
                  maxLines: 2,
                  style: TextStyle(fontSize: 30),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: AutoSizeText(
                  'Greyhound divisively hello coldly wonderfully marginally far upon excluding.',
                  style: TextStyle(
                      color: Colors.white.withOpacity(0.6), fontSize: 20),
                ),
              ),
              ButtonBar(
                alignment: MainAxisAlignment.start,
                children: [
                  TextButton(
                    onPressed: () {
                      // Perform some action
                    },
                    child: const Text('ACTION 1'),
                  ),
                  TextButton(
                    onPressed: () {
                      // Perform some action
                    },
                    child: const Text('ACTION 2'),
                  ),
                ],
              ),
              Image.network('https://source.unsplash.com/random'),
            ],
          ),
        ),
      ),
    );
  }
}
